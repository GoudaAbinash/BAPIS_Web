import { DisablecopyPasteDirective } from './disablecopy-paste.directive';

describe('DisablecopyPasteDirective', () => {
  it('should create an instance', () => {
    const directive = new DisablecopyPasteDirective();
    expect(directive).toBeTruthy();
  });
});
