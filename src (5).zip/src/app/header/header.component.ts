import { Component, Input, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Input() quoteNo: string = "";
  userId;
  loginFlag;
  isAdmin: boolean = false;
  constructor(private api: CommonService) { }

  ngOnInit() {
    let sessionData = this.api.decy(sessionStorage.getItem('userDetails'));
    this.userId = sessionData[0].UserId;
    this.loginFlag = sessionData[0].loginFlag;
    // this.userId = JSON.parse(sessionStorage.getItem('userDetails'))[0].UserId;

    this.api.getUcoObjectRights(this.userId).subscribe((sus) => {
      console.log(JSON.parse(JSON.parse(sus).ResponseMessage).Table);
      if (JSON.parse(JSON.parse(sus).ResponseMessage).Table.length > 0) {
        this.isAdmin = true;
      }
    })
  }
  logout() {
    this.api.logout();
  }
}
