export class Receipt {
    uid: string
    tranDate: string
    amount: string
    fgTranNo: string
    branchCode: string
    clientId: string
    agentCode: string;
    quoteNo:string='';
    tranRefDate:string='';
    receiptusername:string='';
    receiptvendorname:string='';
}