import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public loginForm: any;
  msg = "";
  loading = false;
  bankName: '';
  hide = true;
  constructor(private api: CommonService, private router: Router) { }

  ngOnInit() {
    sessionStorage.clear();
    this.loginForm = new FormGroup({
      bankName: new FormControl("", Validators.required),
      username: new FormControl("", Validators.required),
      password: new FormControl("", Validators.required)
    });

  }
  get CD() { return this.loginForm.controls; }
  login(obj) {
    if (this.loginForm.status == "VALID") {
      this.loading = true;

      this.api.userValidate(obj).subscribe((sus) => {
        let res = JSON.parse(sus.res);
        if (res.ResponseFlag == 1) {
          sessionStorage.setItem('userDetails', this.api.ency(res.ResponseMessage));
          // Admin Panel
          this.api.getUcoObjectRights(this.loginForm.value.username).subscribe((sus) => {
            sessionStorage.setItem('ucoObjRights', this.api.ency(JSON.parse(sus).ResponseMessage));
          })
          this.router.navigate(['quote']);
          sessionStorage.setItem('t', sus.token);
        } else {
          this.msg = "Wrong Username or password!";
        }
        this.loading = false;
      }, err => {
        console.log(err);
        this.loading = false;
      })
    }
  }
}
