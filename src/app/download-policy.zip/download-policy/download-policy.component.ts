import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-download-policy',
  templateUrl: './download-policy.component.html',
  styleUrls: ['./download-policy.component.scss']
})
export class DownloadPolicyComponent implements OnInit {
  quoteNo = '';
  policy = '';
  error = '';
  loading = false;
  constructor(private api:CommonService, private activeR: ActivatedRoute) { }

  ngOnInit() {
    console.log(this.activeR.snapshot.paramMap.get("id"));
    if(this.activeR.snapshot.paramMap.get("id")){
      this.policy = this.api.decy(this.activeR.snapshot.paramMap.get("id"));
    }
  }
  getPolicy(p){
    if(p != ''){
      this.loading = true;
      let obj = {'policyNo': p};
      this.api.getPolicyDoc(obj).subscribe((sus)=>{
        console.log(sus);
        if(sus.ResponseFlag == 1){
          
        }else{
          this.error = sus.ResponseMessage;
        }
        this.loading = false;
      }, err=>{ 
        console.log(err);
      });
    }else{
      alert("Please enter a valid policy number!");
    }
  }
}
