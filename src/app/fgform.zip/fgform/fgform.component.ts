import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

interface Animal {name: string; value:string;}

@Component({
  selector: 'app-fgform',
  templateUrl: './fgform.component.html',
  styleUrls: ['./fgform.component.css']
})
export class FGFormComponent implements OnInit {
  selectFormControl = new FormControl('', Validators.required);
  emailFormControl = new FormControl('', [Validators.required]);
  animalControl = new FormControl('', Validators.required);
  bookControl = new FormControl('', Validators.required);
  coverControl = new FormControl('', Validators.required);
  BurglaryControl = new FormControl('', Validators.required);
  PercentageControl = new FormControl('', Validators.required);
  NomineeControl = new FormControl('', Validators.required);
  customerType = new FormControl('', Validators.required);
  percentage = new FormControl('', Validators.required);
  animals: Animal[] = [
    {name: 'Mr', value:'Mr'},
    {name: 'Mrs', value:'Mrs'},
  ];
  books: Animal[] = [
    {name: 'Aquarium', value:'0336'},
    {name: 'Automobile spare parts excluding Tyre', value:'0336'},
    {name: 'Bakery products', value:'0336'},
    {name: 'Beauty Salon and Barbar shops', value:'0336'},
    {name: 'Book stores', value:'0336'},
    {name: 'Canned Juices', value:'0336'},
    {name: 'CDs, DVDs store', value:'0336'},
    {name: 'Dairy shops', value:'0336'},
    {name: 'Electric and hardware stores', value:'0336'},
    {name: 'Florist Shops', value:'0336'},
    {name: 'Frozen Food', value:'0336'},
    {name: 'Fruits and Vegetables shop', value:'0336'},
    {name: 'General stores', value:'0336'},
    {name: 'Gifts shops and stores', value:'0336'},
    {name: 'Glass trading shops', value:'0336'},
    {name: 'Grocery Shop Like FMCG(Fast Moving Consumable Goods)', value:'0336'},
    {name: 'Internet surfing/ cyber shops/Gaminig', value:'0336'},
    {name: 'Laundry Shops', value:'0336'},
    {name: 'Marble and Granite shops', value:'0336'},
    {name: 'Meat shops and Fish shop', value:'0336'},
    {name: 'Medical and General stores', value:'0336'},
    {name: 'Mobile repairing shop', value:'0336'},
    {name: 'Motor Vechile showroom', value:'0033'},
    {name: 'Optician(Sells Glass and Contact Lenses)', value:'0336'},
    {name: 'Others', value:'0031'},
    {name: 'Pet Shops', value:'0336'},
    {name: 'Plumbing and sanitory stores', value:'0336'},
    {name: 'Pulses', value:'0336'},
    {name: 'Pulses and Cereals', value:'0336'},
    {name: 'Stationery', value:'0336'},
    {name: 'Supermarket', value:'0336'},
    {name: 'Tailor shops', value:'0336'},
    {name: 'Tea, Coffee and Juices', value:'0336'},
    {name: 'Toys Store', value:'0336'},
    {name: 'Trading of Steel, Bricks, Cements', value:'0336'},
    {name: 'Watches', value:'0336'},
    {name: 'Chemical Shop', value:'0031'},
    {name: 'Fire-cracker', value:'0031'},
  ];
  covers: Animal[] = [
    {name: 'Building', value:'1A**'},
    {name: 'Content', value:'1B**'},
    {name: 'Tenant Liability', value:'1L**'},
    {name: 'Alternate Accommodation', value:'1M**'},
    {name: 'Escalation', value:'1O**'},
    {name: 'Omission to Insure Addition', value:'1P**'}
  ]
  Burglary: Animal[] = [
    {name: 'Content', value:'2A**'},
    {name: 'First Loss Percentage', value:''},
  ]
  Percentage = [
    {name: '25'},
    {name: '40'},
    {name: '50'},
    {name: '75'},
  ]
  Nominee: Animal[] = [
    {name: 'Brother', value:'BRO'},
    {name: 'Sister', value: 'SIS'},
    {name: 'ETC', value:'ETC'}
  ]

  constructor() { }

  ngOnInit(): void {

  }

}
